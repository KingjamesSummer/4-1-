package mapper;

public interface UserMapper {
}
